package Exceptions;

public class ObjectNotFoundException extends Exception{
	
	public ObjectNotFoundException() {}
	
	public ObjectNotFoundException(String msg) {
		super(msg);
	}

}
