package Exceptions;

public class InvalidGenderException extends Exception{
	
	public InvalidGenderException() {}
	
	public InvalidGenderException(String msg) {
		super(msg);
	}

}
