package Exceptions;

public class InvalidNgoIdException extends Exception{
	
	public InvalidNgoIdException() {}
	
	public InvalidNgoIdException(String msg) {
		super(msg);
	}

}
